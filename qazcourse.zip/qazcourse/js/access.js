// Қолжетімділік және баға. Төлем қосылғанда тек осы файл мен бэкэнд өзгереді:
// курстың isFree:false және price мәнін қойсаңыз, сатып алу батырмасы мен шектеу автоматты қосылады.
const Access={
 can(course,user){return course.isFree||(user.purchases||[]).includes(course.id)},
 priceLabel(c){return c.isFree?"Тегін":`${c.price.toLocaleString("ru-RU")} ₸`},
 buyButton(c){return `<button class="btn off" disabled title="Төлем жүйесі жақын арада қосылады">Сатып алу · ${this.priceLabel(c)}</button>`}
};
const Progress={
 key:u=>`qc_done_${u.id}`,
 all(u){try{return JSON.parse(localStorage.getItem(this.key(u)))||[]}catch{return[]}},
 has(u,id){return this.all(u).includes(id)},
 toggle(u,id){const a=this.all(u),i=a.indexOf(id);i<0?a.push(id):a.splice(i,1);localStorage.setItem(this.key(u),JSON.stringify(a))}
};
