// Бэкэнд дайын болғанда API_BASE мәнін көрсетіңіз (мыс. "https://api.qazcourse.kz").
// null болса, сайт браузердің localStorage-ын уақытша база ретінде қолданады.
window.QC_CONFIG={API_BASE:null};
