// Авторизация қабаты. Бүкіл сайт тек осы Auth объектісін қолданады.
// Бұрынғы жобаның нақты авторизациясы бар болса, төмендегі api() бөлігін ғана ауыстырыңыз.
const Auth=(()=>{
 const API=window.QC_CONFIG.API_BASE,UK="qc_users",SK="qc_session";
 const read=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
 const hash=async s=>{try{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));
  return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}catch{return btoa(s)}};
 const pub=u=>({id:u.id,name:u.name,email:u.email,purchases:u.purchases||[]});
 async function api(path,body){const r=await fetch(API+path,{method:"POST",credentials:"include",
  headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.message||"Сервер қатесі");return d}
 return{
  async register({name,email,password}){
   email=email.trim().toLowerCase();
   if(API){const d=await api("/auth/register",{name,email,password});localStorage.setItem(SK,JSON.stringify(d.user));return d.user}
   const users=read(UK,[]);if(users.some(u=>u.email===email))throw new Error("Бұл email тіркелген");
   const u={id:Date.now().toString(36),name:name.trim(),email,pass:await hash(password),purchases:[]};
   users.push(u);localStorage.setItem(UK,JSON.stringify(users));localStorage.setItem(SK,JSON.stringify(pub(u)));return pub(u)},
  async login({email,password}){
   email=email.trim().toLowerCase();
   if(API){const d=await api("/auth/login",{email,password});localStorage.setItem(SK,JSON.stringify(d.user));return d.user}
   const h=await hash(password),u=read(UK,[]).find(x=>x.email===email&&x.pass===h);
   if(!u)throw new Error("Email немесе құпия сөз қате");
   localStorage.setItem(SK,JSON.stringify(pub(u)));return pub(u)},
  user:()=>read(SK,null),
  logout(){localStorage.removeItem(SK);location.href="login.html"},
  require(){const u=this.user();if(!u)location.replace("login.html");return u},
  guest(){if(this.user())location.replace("dashboard.html")}};
})();
