const page=document.body.dataset.page,q=new URLSearchParams(location.search);
const main=document.getElementById("main");
if(page==="login"||page==="register"){
 Auth.guest();
 const f=document.getElementById("f"),m=document.getElementById("msg");
 f.addEventListener("submit",async e=>{e.preventDefault();m.textContent="";
  const d=Object.fromEntries(new FormData(f));
  if(page==="register"&&d.password.length<6){m.textContent="Құпия сөз кемінде 6 таңба болсын";return}
  f.querySelector("button").disabled=true;
  try{await Auth[page](d);location.href="dashboard.html"}
  catch(err){m.textContent=err.message;f.querySelector("button").disabled=false}});
}
if(page==="dashboard"){
 const u=renderShell("home");
 if(u)main.innerHTML=`<h1 class="t">Сәлем, ${esc(u.name.split(" ")[0])}!</h1>
 <p class="sub">Сыныбыңды таңдап, оқуды жалғастыр.</p>
 <h2 id="courses" style="font-size:1.2rem">Менің курстарым</h2>
 <div class="grid">${COURSES.map(c=>{
  const total=countLessons(c),done=c.topics.flatMap(t=>t.lessons).filter(l=>Progress.has(u,l.id)).length,p=total?Math.round(done/total*100):0,ok=Access.can(c,u);
  return `<article class="course"><div class="grade">${c.grade}</div>
  <span class="tag ${c.isFree?"":"paid"}">${Access.priceLabel(c)}</span>
  <h3>${esc(c.title)}</h3><div class="meta">${c.topics.length} тақырып · ${total} сабақ</div>
  <div class="bar" title="${p}%"><i style="width:${p}%"></i></div><div class="meta">Өтілгені: ${done}/${total}</div>
  ${ok?`<a class="btn" href="course.html?id=${c.id}">Курсты ашу</a>`:Access.buyButton(c)}</article>`}).join("")}</div>`;
}
if(page==="course"){
 const u=renderShell("courses"),c=courseById(q.get("id"));
 if(u&&!c)location.replace("dashboard.html");
 else if(u){
  document.title=c.title+" · QazCourse";
  if(!Access.can(c,u))main.innerHTML=`<div class="lock"><h2>${esc(c.title)}</h2><p>Бұл курс ақылы.</p>${Access.buyButton(c)}</div>`;
  else main.innerHTML=`<div class="crumb"><a href="dashboard.html">Басты бет</a> / ${esc(c.title)}</div>
  <h1 class="t">${esc(c.title)}</h1><p class="sub">Тақырып пен сабақты таңдаңыз.</p>
  ${c.topics.map(t=>`<section class="topic"><h3>${esc(t.title)}</h3>${t.lessons.map(l=>
   `<a class="les" href="lesson.html?course=${c.id}&lesson=${l.id}"><span>${esc(l.title)}</span>
   ${Progress.has(u,l.id)?'<span class="ok">✓ Өтілді</span>':""}</a>`).join("")}</section>`).join("")}`;
 }
}
if(page==="lesson"){
 const u=renderShell("courses"),c=courseById(q.get("course"));
 const L=c&&c.topics.flatMap(t=>t.lessons).find(l=>l.id===q.get("lesson"));
 if(u&&(!c||!L||!Access.can(c,u)))location.replace("dashboard.html");
 else if(u){
  document.title=L.title+" · QazCourse";
  const tabs=[["presentations","Презентациялар"],["materials","Теориялық материалдар"],["exercises","Есептер мен тапсырмалар"]];
  const item=m=>{const t=m.type;
   const body=t==="video"?`<iframe src="${esc(m.url)}" allowfullscreen title="${esc(m.title)}"></iframe>`:
    m.url?`<a class="btn ghost" href="${esc(m.url)}" target="_blank" rel="noopener">${t==="pdf"?"PDF ашу":"Ашу"}</a>`:"";
   return `<div class="item"><div><b>${esc(m.title)}</b>${m.text?`<div class="meta">${esc(m.text)}</div>`:""}${t==="video"?body:""}</div>${t==="video"?"":body}</div>`};
  const draw=k=>{
   document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("on",b.dataset.k===k));
   const a=L[k];document.getElementById("panel").innerHTML=a.length?a.map(item).join(""):'<div class="empty">Бұл бөлімнің материалдары жақын арада қосылады.</div>'};
  main.innerHTML=`<div class="crumb"><a href="dashboard.html">Басты бет</a> / <a href="course.html?id=${c.id}">${esc(c.title)}</a></div>
  <h1 class="t">${esc(L.title)}</h1>
  <div class="tabs" role="tablist">${tabs.map(([k,n])=>`<button class="tab" data-k="${k}">${n}</button>`).join("")}</div>
  <div class="panel" id="panel"></div>
  <p><button class="btn ghost" id="done"></button></p>`;
  const btn=document.getElementById("done"),sync=()=>btn.textContent=Progress.has(u,L.id)?"✓ Өтілді (қайтару)":"Сабақты өтілді деп белгілеу";
  sync();btn.onclick=()=>{Progress.toggle(u,L.id);sync()};
  document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>draw(b.dataset.k));draw("presentations");
 }
}
