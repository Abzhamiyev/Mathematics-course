function renderShell(active){
 const u=Auth.require();if(!u)return null;
 const side=document.getElementById("side");
 side.innerHTML=`<a class="logo" href="dashboard.html">Qaz<b>Course</b></a>
 <a class="nav ${active==="home"?"on":""}" href="dashboard.html">Басты бет</a>
 <a class="nav ${active==="courses"?"on":""}" href="dashboard.html#courses">Менің курстарым</a>
 <span class="nav soon">Төлемдер (жақында)</span><div class="spacer"></div>
 <div class="user"><b>${esc(u.name)}</b><small>${esc(u.email)}</small><button id="out">Шығу</button></div>`;
 document.getElementById("out").onclick=()=>Auth.logout();
 document.getElementById("menu").onclick=()=>side.classList.toggle("open");
 side.addEventListener("click",e=>{if(e.target.closest("a"))side.classList.remove("open")});
 return u;
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
const courseById=id=>COURSES.find(c=>c.id===id);
const countLessons=c=>c.topics.reduce((n,t)=>n+t.lessons.length,0);
